import os
import email
import imaplib
import smtplib
import sys
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.header import decode_header
import re


class EmailClient:
    def __init__(self, email_address, password):
        self.email_address = email_address
        self.password = password
        self.smtp_server = 'smtp.gmail.com'
        self.smtp_port = 587
        self.imap_server = 'imap.gmail.com'
        self.imap_port = 993

    def send_email(self):
        to_address = input("Enter recipient's email address: ")
        subject = input("Enter email subject: ")
        body = input("Enter email body: ")
        attachment = input("Enter attachment file path (leave blank for no attachment): ").strip()

        msg = MIMEMultipart()
        msg['From'] = self.email_address
        msg['To'] = to_address
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        if attachment:
            attachment_name = os.path.basename(attachment)  #Selectarea doar numelui din path
            with open(attachment, 'rb') as file:
                part = MIMEApplication(file.read(), Name=attachment_name)
            part['Content-Disposition'] = f'attachment; filename="{attachment_name}"'
            msg.attach(part)

        print("Message sent")

        server = smtplib.SMTP(self.smtp_server, self.smtp_port)
        server.starttls()
        server.login(self.email_address, self.password)
        server.send_message(msg)
        server.quit()

    def download_email(self, msg):
        from_address = msg['From']

        # Extrage adresa de email a expeditorului din campul "From"
        match = re.search(r'<(.+?)>', from_address)
        if match:
            sender_email = match.group(1)
        else:
            sender_email = from_address

        # Creeaza un director cu numele adresa de email a expeditorului
        folder_name = sender_email if sender_email else 'Email'
        folder_path = os.path.join(os.path.expanduser('~'), 'Downloads', folder_name)

        try:
            os.makedirs(folder_path, exist_ok=True)
        except OSError as e:
            print(f"Error: {e}")

        # Salveaza continutul mesajului
        text_content = msg.get_payload()
        text_file_path = os.path.join(folder_path, 'email_content.html')
        with open(text_file_path, 'w', encoding='utf-8') as text_file:
            if isinstance(text_content, list):
                for part in text_content:
                    text_file.write(part.get_payload(decode=True).decode('utf-8', 'ignore'))
            else:
                text_file.write(text_content)

        # Descarca si salveaza toate atasamentele din mesaj
        for part in msg.walk():
            if part.get_content_maintype() == 'multipart':
                continue
            if part.get('Content-Disposition') is None:
                continue

            filename = part.get_filename()
            if filename:
                # Extrage doar numele fisierului din calea atasamentului
                attachment_name = os.path.basename(filename)
                attachment_path = os.path.join(folder_path, attachment_name)
                with open(attachment_path, 'wb') as attachment_file:
                    attachment_file.write(part.get_payload(decode=True))
                    print(f"Attachment saved: {attachment_path}")

        print(f"Email downloaded successfully to {folder_path}")

    def receive_emails(self):
        mail = imaplib.IMAP4_SSL(self.imap_server)
        mail.login(self.email_address, self.password)
        mail.select('inbox')

        result, data = mail.search(None, 'ALL')
        ids = data[0]
        id_list = ids.split()

        total_messages = len(id_list)
        print(f"Total messages: {total_messages}")

        start_index = int(input("Enter the start index of messages: "))
        end_index = int(input("Enter the end index of messages: "))

        emails = []
        for i in range(start_index - 1, end_index):
            result, data = mail.fetch(id_list[i], '(RFC822)')
            raw_email = data[0][1]
            msg = email.message_from_bytes(raw_email)

            # Decodificam subiectul mesajului
            subject = msg['Subject']
            decoded_subject = ' '.join(
                part[0].decode(part[1] if part[1] else 'utf-8') if isinstance(part[0], bytes) else part[0] for part in
                decode_header(subject))

            # Afisam detaliile mesajului cu subiectul decodificat
            print(f"Message {i}:")
            print("Subject:", decoded_subject)
            print("From:", msg['From'])
            print("Date:", msg['Date'])
            print()

            emails.append(i + 1)

        mail.close()
        mail.logout()

        return emails

    def select_and_download_email(self, emails):
        if not emails:
            print("There are no emails to select.")
            return

        total_messages = len(emails)
        print(f"Total messages available for download: {total_messages}")

        for i, email_index in enumerate(emails, start=1):
            print(f"{i}. Message index: {email_index}")

        while True:
            try:
                choice = int(input("Select the index of the email to download (0 to cancel): "))

                if choice == 0:
                    break
                elif 1 <= choice <= len(emails):
                    # Obtinem identificatorul mesajului
                    message_id = emails[choice - 1]
                    mail = imaplib.IMAP4_SSL(self.imap_server)
                    mail.login(self.email_address, self.password)
                    mail.select('inbox')
                    result, data = mail.fetch(str(message_id), '(RFC822)')
                    raw_email = data[0][1]
                    msg = email.message_from_bytes(raw_email)
                    self.download_email(msg)
                    mail.close()
                    mail.logout()
                    break
                else:
                    print("Invalid choice. Please select a valid index.")
            except ValueError:
                print("Invalid input. Please enter a number.")

    def fetch_email(self, email_index):
        mail = imaplib.IMAP4_SSL(self.imap_server)
        mail.login(self.email_address, self.password)
        mail.select('inbox')

        result, data = mail.search(None, 'ALL')
        ids = data[0]
        id_list = ids.split()

        if email_index < 1 or email_index > len(id_list):
            print("Invalid email index.")
            return None

        result, data = mail.fetch(id_list[email_index - 1], '(RFC822)')
        raw_email = data[0][1]
        msg = email.message_from_bytes(raw_email)

        mail.close()
        mail.logout()

        return msg

    def reply_to_email(self, emails):
        if not emails:
            print("There are no emails to reply to.")
            return

        total_messages = len(emails)
        print(f"Total messages available for reply: {total_messages}")

        # print("Select the index of the email to reply to (0 to cancel):")
        for i, email_index in enumerate(emails, start=1):
            print(f"{i}. Message index: {email_index}")

        try:
            choice = int(input("Select the index of the email to reply to (0 to cancel):"))
            if choice == 0:
                print("Reply canceled.")
                return
            elif 1 <= choice <= len(emails):
                email_index = emails[choice - 1]
                original_msg = self.fetch_email(email_index)
            else:
                print("Invalid choice. Please select a valid index.")
                return
        except ValueError:
            print("Invalid input. Please enter a number.")
            return

            # Extrage adresa de email a expeditorului din mesaj
        from_address = original_msg['From']

        # Introducerea subiectului si a mesajului
        subject = input("Enter reply subject: ")
        body = input("Enter reply body: ")

        # Crearea mesajului pentru reply
        reply_msg = MIMEMultipart()
        reply_msg['From'] = self.email_address
        reply_msg['To'] = from_address
        reply_msg['Subject'] = subject
        reply_msg.attach(MIMEText(body, 'plain'))

        # Adaugarea atasamentului
        attachment = input("Enter attachment file path (leave blank for no attachment): ").strip()
        if attachment:
            attachment_name = os.path.basename(attachment)
            with open(attachment, 'rb') as file:
                part = MIMEApplication(file.read(), Name=attachment_name)
            part['Content-Disposition'] = f'attachment; filename="{attachment_name}"'
            reply_msg.attach(part)

        # Trimiterea mesajului
        server = smtplib.SMTP(self.smtp_server, self.smtp_port)
        server.starttls()
        server.login(self.email_address, self.password)
        server.send_message(reply_msg)
        server.quit()
        print(f"Message sent")

        # Login/PAss
client = EmailClient('dumitrucernei2202@gmail.com', 'isfr mwvv hywv pihw')

while True:
    print("1. Send Email")
    print("2. Receive Emails")
    print("3. Download Email")
    print("4. Reply to Email")
    print("5. Exit")

    choice = input("Enter your choice: ")

    if choice == '1':
        client.send_email()
    elif choice == '2':
        emails = client.receive_emails()
    elif choice == '3':
        client.select_and_download_email(emails)
    elif choice == '4':
        client.reply_to_email(emails)
    elif choice == '5':
        sys.exit()
        break
    else:
        print("Invalid choice. Please enter a valid option.")
