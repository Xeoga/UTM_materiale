In consola rulam `python main.py`
