se inscrie posta si parola
in send_message se inscrie subiectul , mesajul posta recipientului si atasamentul la dorinta
email-urile primite sunt stocate in fisierele pop3.txt si imap.txt
atasamentele sunt descarcate in work directory
in terminal se introduce python main.py