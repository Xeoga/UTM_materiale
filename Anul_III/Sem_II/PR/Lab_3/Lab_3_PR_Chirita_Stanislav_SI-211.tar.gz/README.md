python3 Lab_3.dns_resolver.py resolve 8.8.8.8
python3 Lab_3.dns_resolver.py use 8.8.4.4 dns.google
python3 Lab_3.dns_resolver.py resolve dns.google
